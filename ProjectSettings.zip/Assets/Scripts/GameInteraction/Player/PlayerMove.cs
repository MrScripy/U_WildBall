using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace WildBall.Inputs
{
    [RequireComponent(typeof(Rigidbody))]
    public class PlayerMove : MonoBehaviour
    {
        [SerializeField] private float speed;
        [SerializeField] private Transform orientation;
        [SerializeField] private float jumpForce;
        [SerializeField] private float jumpCoolDown;
        [SerializeField] private float airMultiplier;
        private bool readyToJump = true;

        private float horizontalInput;
        private float verticalInput;

        private Vector3 moveDir;

        private Rigidbody rb;

        private void Start()
        {
            rb = GetComponent<Rigidbody>();
            rb.freezeRotation = true;
        }

        private void Update()
        {
            MyInput();
        }

        private void FixedUpdate()
        {
            MovePlayer();
        }

        private void MyInput()
        {
            horizontalInput = Input.GetAxis(GlobalStringVars.Horizontal);
            verticalInput = Input.GetAxis(GlobalStringVars.Vertical);
            if (Input.GetKey(KeyCode.Space) && readyToJump)
            {
                readyToJump = false;
                Jump();
                Invoke(nameof(ResetJump), jumpCoolDown);
            }
        }

        private void MovePlayer()
        {
            // walk in direction player're looking
            moveDir = orientation.forward * verticalInput + orientation.right * horizontalInput;
            rb.AddForce(moveDir.normalized * speed, ForceMode.VelocityChange);
        }

        private void Jump()
        {
            rb.velocity = new Vector3(rb.velocity.x, 0f, rb.velocity.z);
            rb.AddForce(transform.up * jumpForce, ForceMode.Impulse);
        }

        private void ResetJump()
        {
            readyToJump = true;
        }

        //private Rigidbody player;
        //private Vector3 vector;
        //private float horizontal;
        //private float vertical;


        //private void Start()
        //{
        //    player = GetComponent<Rigidbody>();
        //}

        //private void Update()
        //{
        //    GetInput();
        //    MoveDirection();
        //}

        //private void FixedUpdate()
        //{
        //    MoveCharacter();
        //}

        //#region privateMethods
        //private void GetInput()
        //{
        //    horizontal = Input.GetAxis(GlobalStringVars.Horizontal);
        //    vertical = Input.GetAxis(GlobalStringVars.Vertical);
        //}

        //private void MoveDirection()
        //{
        //    vector = new Vector3(horizontal, 0, vertical);
        //}

        //private void MoveCharacter()
        //{
        //    player.AddForce(vector * speed, ForceMode.VelocityChange);
        //}
        //#endregion
    }
}

