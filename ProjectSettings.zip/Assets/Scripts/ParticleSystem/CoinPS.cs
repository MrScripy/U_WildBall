using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CoinPS : MonoBehaviour
{
    [SerializeField] private ParticleSystem stars;
    [SerializeField] private GameObject coin;

    private void OnTriggerEnter(Collider other)
    {
        coin.SetActive(false);
        stars.Play();
    }
}
