using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class PauseManager : MonoBehaviour
{
    [SerializeField] GameObject pausePanel;

    private void Start()
    {
        pausePanel.SetActive(false);
        Time.timeScale = 1;

    }

    public void OnPauseButtonClick()
    {
        //add pause for the game
        pausePanel.SetActive(true);
        Time.timeScale = 0;
    }

    private void Update()
    {
        if (Input.GetKey(KeyCode.Escape))
        {
            OnPauseButtonClick();
            Cursor.lockState = CursorLockMode.Confined;
            Cursor.visible = true;
        }
    }

    public void OnMainMenuButtonClick()
    {
        SceneManager.LoadScene(0);
        Time.timeScale = 1;
    }

    public void OnRestartLevelButtonClick()
    {
        SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex);
        Cursor.lockState = CursorLockMode.Locked;
        Cursor.visible = false;
    }

    public void OnBackToGameButtonClick()
    {
        // add continuing game
        pausePanel.SetActive(false);        
        Cursor.lockState = CursorLockMode.Locked;
        Cursor.visible = false;
        Time.timeScale = 1;
    }

}
